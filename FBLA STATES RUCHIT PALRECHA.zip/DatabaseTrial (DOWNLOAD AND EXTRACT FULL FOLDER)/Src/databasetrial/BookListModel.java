/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databasetrial;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.AbstractListModel;

/**
 *
 * @author Ruchit22
 */

public class BookListModel extends AbstractListModel {
    
    DBConnection db;
    private int rownum;
    private  ArrayList<String> ResultSets;
    
    public BookListModel(ResultSet rs) {
      
         ResultSets=new ArrayList<String>();  
    
      try{
        while(rs.next()){
            String row=rs.getString("title");
            ResultSets.add(row);
        }  
      }
      catch(Exception e){
          System.out.println("Exception in BookListModel");
          System.out.println(e.getClass().getName());
            }
    }
    
    public Object getElementAt(int rowindex) {  
       String row = ResultSets.get(rowindex);
       return row;
    }
    
    public int getSize() { 
        return ResultSets.size();
    }

    
      
}
