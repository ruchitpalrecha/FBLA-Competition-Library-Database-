/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databasetrial;

import javax.swing.table.AbstractTableModel;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author Ruchit22
 */
public class MemberTableModel extends AbstractTableModel {
    
    private int colnum=5;
    private int rownum;
    DBConnection db;
    private String[] colNames={
        "ID", "First Name","Last Name","Type", "Sex"
    };
    private  ArrayList<String[]> ResultSets;
    
     public MemberTableModel(ResultSet rs) {
      
         ResultSets=new ArrayList<String[]>();  
    
      try{
        while(rs.next()){
              String[] row={
                rs.getString("member_id"),rs.getString("first_name"),rs.getString("last_name"),rs.getString("member_type"), rs.getString("sex")
            };
            ResultSets.add(row);
         }   
      }
      catch(Exception e){
          System.out.println("Exception in MemberTableModel");
          System.out.println(e.getClass().getName());
            }
        
    }
    
    public Object getValueAt(int rowindex, int columnindex) {  
       String[] row=ResultSets.get(rowindex);
       return row[columnindex];
    }

    public int getRowCount() { 
        return ResultSets.size();
    }

    public int getColumnCount(){
         return colnum;
    }
    
    public String getColumnName(int param) {

       return colNames[param];
    }
  
}
